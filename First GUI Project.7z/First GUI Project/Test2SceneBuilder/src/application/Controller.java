package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;


public class Controller {
	
	@FXML
	private Text myLabel;
	@FXML
	private TextField usenameText;
	@FXML
	private TextField passText;
	@FXML
	private TextField emailText;
	@FXML
	private Button myButton;
	
	String username;
	String password;
	String email;
	
	// Taken from https://stackoverflow.com/questions/624581/what-is-the-best-java-email-address-validation-method
	// Attempted to use https://commons.apache.org/proper/commons-validator/apidocs/org/apache/commons/validator/routines/EmailValidator.html , didn't work out
    public boolean isValidEmailAddress(String email) {
        String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
        java.util.regex.Matcher m = p.matcher(email);
        return m.matches();
    }
	
	public void submit(ActionEvent sub) {
		//System.out.println("WOOYEAH");
		try {
			username = usenameText.getText();
			password = passText.getText();
			email = emailText.getText();
			
			//System.out.println(username);
			//System.out.println(password);
			//System.out.println(email);

			int skip = 0;
			
			if (isValidEmailAddress(email)) {
				System.out.println("VALID EMAIL");
				
				File savedata = new File("C:\\Users\\arkan\\Documents\\data\\savedata.txt");
				if (savedata.exists()) {
					// If file already exists, we need to get a list of emails and usernames, and check the new username and email against those lists
					BufferedReader bo = new BufferedReader(new FileReader(savedata));
					String line;
					//System.out.println("Got here 1");
					List usernames = new ArrayList();
					List emails = new ArrayList();
					
					
					line = bo.readLine();
					while(line != null) {
						//System.out.println("Got here 2");
						String [] terms = line.split(";", 3);
						
						//System.out.println(terms[0].substring(10));
						//System.out.println(terms[2].substring(7));
						//System.out.println("Got here 3");
						usernames.add(terms[0].substring(10));
						emails.add(terms[2].substring(7));
						line = bo.readLine();
					}
					
					System.out.println("ALL USERNAMES");
					System.out.println(usernames);
					System.out.println("ALL Emails");
					System.out.println(emails);
					
					System.out.println("USERNAME");
					System.out.println(username);
					System.out.println("EMAIL");
					System.out.println(email);
					
					
					// do we have a same email or username?
					if(usernames.contains(username)) {
						System.out.println("Got here 4");
						myLabel.setText("Username Already Exists");
						skip = 1;
					}
					else if(emails.contains(email)) {
						System.out.println("Got here 5");
						myLabel.setText("Email Already Exists");
						skip = 1;
					}
						
					
					bo.close();
					
				}
				//Write to file

				
				FileWriter writer = new FileWriter(savedata, true);
				BufferedWriter br = new BufferedWriter(writer);
				
				if (skip != 1) {
					br.write("Username: " + username + ";");
					br.write("Password: " + password + ";");
					br.write("Email: " + email + "\n");
					br.close();
					writer.close();


					myLabel.setText("Account Created!");
				}
			
			}
			else {
				System.out.println("INVALID EMAIL");
				myLabel.setText("Invalid Email Address");
			}
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
	}
}
